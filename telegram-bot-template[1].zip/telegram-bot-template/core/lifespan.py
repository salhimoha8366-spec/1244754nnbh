import logging
from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine, async_sessionmaker

from core.config import settings

logger = logging.getLogger(__name__)

# Global instances
db_engine: AsyncEngine | None = None
async_session_factory = None
redis_client: aioredis.Redis | None = None


@asynccontextmanager
async def lifespan(app=None):
    """Manage startup and shutdown of shared resources."""
    global db_engine, async_session_factory, redis_client

    # ── Startup ──────────────────────────────────────────
    logger.info("Initializing database engine...")
    db_engine = create_async_engine(
        settings.DATABASE_URL,
        echo=settings.DEBUG,
        pool_size=10,
        max_overflow=20,
    )
    async_session_factory = async_sessionmaker(
        db_engine, expire_on_commit=False
    )

    logger.info("Connecting to Redis...")
    redis_client = aioredis.from_url(
        settings.REDIS_URL,
        encoding="utf-8",
        decode_responses=True,
    )
    await redis_client.ping()
    logger.info("All resources initialized.")

    yield

    # ── Shutdown ─────────────────────────────────────────
    logger.info("Closing database connections...")
    if db_engine:
        await db_engine.dispose()

    logger.info("Closing Redis connection...")
    if redis_client:
        await redis_client.aclose()

    logger.info("Shutdown complete.")


def get_session_factory():
    return async_session_factory


def get_redis() -> aioredis.Redis:
    return redis_client
