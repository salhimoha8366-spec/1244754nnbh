from functools import lru_cache
from typing import Optional

from pydantic import SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # ── Bot ──────────────────────────────────────────────
    BOT_TOKEN: SecretStr
    BOT_ADMIN_IDS: list[int] = []

    # ── Webhook (production) ─────────────────────────────
    USE_WEBHOOK: bool = False
    WEBHOOK_BASE_URL: str = "https://yourdomain.com"
    WEBHOOK_SECRET: str = "your-secret-token"
    PORT: int = 8000

    # ── Database ─────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://user:password@localhost:5432/botdb"

    # ── Redis ────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"

    # ── OpenAI (optional) ────────────────────────────────
    OPENAI_API_KEY: Optional[SecretStr] = None
    OPENAI_MODEL: str = "gpt-4o"

    # ── App ──────────────────────────────────────────────
    DEBUG: bool = False
    APP_NAME: str = "Telegram Bot"

    @field_validator("BOT_ADMIN_IDS", mode="before")
    @classmethod
    def parse_admin_ids(cls, v):
        if isinstance(v, str):
            return [int(i.strip()) for i in v.split(",") if i.strip()]
        return v

    @property
    def bot_token(self) -> str:
        return self.BOT_TOKEN.get_secret_value()


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
