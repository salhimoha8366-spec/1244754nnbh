import logging
from aiogram import Router
from aiogram.types import ErrorEvent

logger = logging.getLogger(__name__)
router = Router(name="errors")


@router.errors()
async def global_error_handler(event: ErrorEvent) -> bool:
    logger.exception(
        "Unhandled exception for update %s: %s",
        event.update.update_id,
        event.exception,
    )
    # Return True to mark error as handled
    return True
