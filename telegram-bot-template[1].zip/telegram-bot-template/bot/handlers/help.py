from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router(name="help")

HELP_TEXT = (
    "📖 <b>قائمة الأوامر:</b>\n\n"
    "/start — بدء التشغيل\n"
    "/help  — عرض هذه الرسالة\n"
    "/stats — إحصائياتي\n\n"
    "يمكنك أيضاً إرسال أي نص وسأرد عليك!"
)


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    await message.answer(HELP_TEXT)
