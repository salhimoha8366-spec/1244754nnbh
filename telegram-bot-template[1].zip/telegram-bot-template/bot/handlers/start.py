from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from bot.keyboards.main_menu import main_menu_keyboard
from db.repositories.user_repo import UserRepository
from core.lifespan import get_session_factory

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    session_factory = get_session_factory()
    async with session_factory() as session:
        repo = UserRepository(session)
        user = await repo.get_or_create(
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name,
        )

    await message.answer(
        f"👋 <b>أهلاً {message.from_user.first_name}!</b>\n\n"
        "أنا بوت متكامل مبني بـ Python, Aiogram و FastAPI.\n"
        "اختر من القائمة أدناه:",
        reply_markup=main_menu_keyboard(),
    )
