from aiogram import Dispatcher

from bot.handlers.start import router as start_router
from bot.handlers.help import router as help_router
from bot.handlers.echo import router as echo_router
from bot.handlers.errors import router as errors_router


def setup_routers(dp: Dispatcher) -> None:
    # Order matters — errors last
    dp.include_router(start_router)
    dp.include_router(help_router)
    dp.include_router(echo_router)
    dp.include_router(errors_router)
