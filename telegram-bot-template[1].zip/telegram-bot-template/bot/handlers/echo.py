from aiogram import Router, F
from aiogram.types import Message

router = Router(name="echo")


@router.message(F.text)
async def echo_message(message: Message) -> None:
    """Echo back any unhandled text message."""
    await message.answer(
        f"📩 استلمت رسالتك:\n<code>{message.text}</code>\n\n"
        "أرسل /help لعرض الأوامر المتاحة."
    )
