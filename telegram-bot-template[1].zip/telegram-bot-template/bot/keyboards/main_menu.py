from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton


def main_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📊 إحصائياتي"), KeyboardButton(text="⚙️ الإعدادات")],
            [KeyboardButton(text="📖 المساعدة")],
        ],
        resize_keyboard=True,
        input_field_placeholder="اختر خياراً...",
    )


def confirm_inline_keyboard(action: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ تأكيد", callback_data=f"confirm:{action}"),
                InlineKeyboardButton(text="❌ إلغاء", callback_data=f"cancel:{action}"),
            ]
        ]
    )
