import logging
import time
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import Message

logger = logging.getLogger(__name__)


class LoggingMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Message, dict[str, Any]], Awaitable[Any]],
        event: Message,
        data: dict[str, Any],
    ) -> Any:
        start = time.monotonic()
        user = event.from_user
        logger.info(
            "IN  | user=%s (@%s) | text=%r",
            user.id,
            user.username,
            (event.text or "")[:80],
        )
        result = await handler(event, data)
        elapsed = (time.monotonic() - start) * 1000
        logger.info("OUT | user=%s | %.1fms", user.id, elapsed)
        return result
