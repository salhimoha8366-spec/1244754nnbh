import logging
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import Message

from core.lifespan import get_redis

logger = logging.getLogger(__name__)


class ThrottlingMiddleware(BaseMiddleware):
    """Rate-limit users using Redis. Default: 1 request/second per user."""

    def __init__(self, rate_limit: float = 1.0) -> None:
        self.rate_limit = rate_limit
        self.key_prefix = "throttle"

    async def __call__(
        self,
        handler: Callable[[Message, dict[str, Any]], Awaitable[Any]],
        event: Message,
        data: dict[str, Any],
    ) -> Any:
        user_id = event.from_user.id
        key = f"{self.key_prefix}:{user_id}"
        redis = get_redis()

        if redis is None:
            return await handler(event, data)

        # Check if key exists (user sent too fast)
        result = await redis.set(key, 1, ex=int(self.rate_limit), nx=True)
        if result is None:
            logger.warning("Throttled user %s", user_id)
            await event.answer("⏳ أرسل رسائل بشكل أبطأ قليلاً.")
            return

        return await handler(event, data)
