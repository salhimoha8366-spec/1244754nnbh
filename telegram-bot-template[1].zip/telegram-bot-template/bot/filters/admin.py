from aiogram.filters import BaseFilter
from aiogram.types import Message

from core.config import settings


class IsAdmin(BaseFilter):
    """Filter: pass only if the user is in the admin list."""

    async def __call__(self, message: Message) -> bool:
        return message.from_user.id in settings.BOT_ADMIN_IDS
