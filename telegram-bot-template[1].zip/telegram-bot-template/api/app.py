from contextlib import asynccontextmanager

from aiogram import Bot, Dispatcher
from aiogram.types import Update
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware

from api.routers import health, stats
from core.config import settings
from core.lifespan import lifespan


def create_app(bot: Bot, dp: Dispatcher) -> FastAPI:

    @asynccontextmanager
    async def _lifespan(app: FastAPI):
        async with lifespan(app):
            yield

    app = FastAPI(
        title=settings.APP_NAME,
        version="1.0.0",
        docs_url="/docs" if settings.DEBUG else None,
        redoc_url=None,
        lifespan=_lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Webhook endpoint ─────────────────────────────────
    @app.post("/webhook")
    async def telegram_webhook(
        request: Request,
        x_telegram_bot_api_secret_token: str = Header(default=None),
    ):
        if x_telegram_bot_api_secret_token != settings.WEBHOOK_SECRET:
            raise HTTPException(status_code=403, detail="Invalid secret token")

        data = await request.json()
        update = Update.model_validate(data)
        await dp.feed_update(bot=bot, update=update)
        return {"ok": True}

    # ── Routers ──────────────────────────────────────────
    app.include_router(health.router, prefix="/api", tags=["health"])
    app.include_router(stats.router, prefix="/api", tags=["stats"])

    return app
