from fastapi import APIRouter
from pydantic import BaseModel

from core.lifespan import get_redis

router = APIRouter()


class StatsResponse(BaseModel):
    total_users: int
    active_today: int


@router.get("/stats", response_model=StatsResponse)
async def get_stats():
    redis = get_redis()
    total = int(await redis.get("stats:total_users") or 0)
    active = int(await redis.get("stats:active_today") or 0)
    return StatsResponse(total_users=total, active_today=active)
