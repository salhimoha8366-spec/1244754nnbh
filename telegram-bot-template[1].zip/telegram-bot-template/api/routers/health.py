from fastapi import APIRouter
from pydantic import BaseModel

from core.lifespan import get_redis

router = APIRouter()


class HealthResponse(BaseModel):
    status: str
    redis: str
    database: str


@router.get("/health", response_model=HealthResponse)
async def health_check():
    redis_status = "ok"
    try:
        redis = get_redis()
        await redis.ping()
    except Exception:
        redis_status = "unavailable"

    return HealthResponse(
        status="ok",
        redis=redis_status,
        database="ok",
    )
